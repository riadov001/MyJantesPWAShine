import { Pool } from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import * as schema from "@shared/schema";

const isProduction = process.env.NODE_ENV === 'production';

let connectionString: string;

if (isProduction && process.env.PRODUCTION_DATABASE_URL) {
  connectionString = process.env.PRODUCTION_DATABASE_URL;
  console.log('[DB] Production: connexion via PRODUCTION_DATABASE_URL');
} else {
  const devUrl = process.env.DEV_DATABASE_URL || process.env.DATABASE_URL;
  if (!devUrl) {
    throw new Error("DEV_DATABASE_URL must be set. Did you forget to provision a database?");
  }
  connectionString = devUrl;
  console.log('[DB] Dev: connexion via DEV_DATABASE_URL');
}

export const pool = new Pool({ connectionString });
export const db = drizzle({ client: pool, schema });
