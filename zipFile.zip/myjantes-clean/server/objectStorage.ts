// Reference: javascript_object_storage blueprint
import { Client } from "@replit/object-storage";
import { Response } from "express";
import { randomUUID } from "crypto";
import * as fs from "fs";
import * as path from "path";
import {
  ObjectAclPolicy,
  ObjectPermission,
} from "./objectAcl";

const FALLBACK_BUCKET_ID = "replit-objstore-f2db546b-8a14-4ea9-9a24-362c38328808";

function getBucketId(): string {
  return process.env.OBJECT_STORAGE_BUCKET_ID || process.env.DEFAULT_OBJECT_STORAGE_BUCKET_ID || process.env.REPLIT_OBJECT_STORAGE_BUCKET_ID || FALLBACK_BUCKET_ID;
}

function getStorageClient(bucketId?: string): Client {
  return new Client({ bucketId: bucketId || getBucketId() });
}

export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
    Object.setPrototypeOf(this, ObjectNotFoundError.prototype);
  }
}

// The object storage service is used to interact with the object storage service.
export class ObjectStorageService {
  private client: Client;
  
  constructor() {
    this.client = getStorageClient();
  }

  async uploadFileBuffer(buffer: Buffer, fileName: string, folder: string = 'uploads'): Promise<string> {
    const objectId = randomUUID();
    const ext = path.extname(fileName);
    const storageName = `${objectId}${ext}`;
    const objectName = `.private/${folder}/${storageName}`;
    
    console.log(`[ObjectStorage] Uploading: ${objectName}, size: ${buffer.length} bytes`);
    
    const result = await this.client.uploadFromFilename 
      ? await this.client.uploadFromBytes(objectName, buffer)
      : await this.client.uploadFromBytes(objectName, buffer);
    
    if (!result.ok) {
      const error = result as { ok: false; error: unknown };
      const errorMsg = typeof error.error === 'string' 
        ? error.error 
        : JSON.stringify(error.error);
      console.error(`[ObjectStorage] Upload failed:`, error.error);
      throw new Error(`Upload failed: ${errorMsg}`);
    }
    
    const objectPath = `/objects/${folder}/${storageName}`;
    console.log(`[ObjectStorage] Upload OK: ${objectPath}`);
    return objectPath;
  }

  // Helper to convert result value to Buffer
  private toBuffer(value: unknown): Buffer {
    if (Buffer.isBuffer(value)) {
      return value;
    } else if (value instanceof Uint8Array) {
      return Buffer.from(value);
    } else if (Array.isArray(value) && value.length > 0) {
      return Buffer.isBuffer(value[0]) ? value[0] : Buffer.from(value[0] as Uint8Array);
    } else {
      return Buffer.from(value as ArrayBuffer);
    }
  }

  // Gets an object from storage by path - supports multiple path formats
  async getObject(objectPath: string): Promise<{ data: Buffer; exists: boolean }> {
    // Try multiple path resolution strategies
    const pathsToTry: string[] = [];
    
    // Strategy 1: If path starts with /objects/, convert to .private/
    if (objectPath.startsWith("/objects/")) {
      const parts = objectPath.slice(1).split("/");
      if (parts.length >= 2) {
        const entityId = parts.slice(1).join("/");
        pathsToTry.push(`.private/${entityId}`);
      }
    }
    
    // Strategy 2: Try the raw path directly (for legacy uploads)
    pathsToTry.push(objectPath);
    
    // Strategy 3: If path doesn't start with .private/, try adding it
    if (!objectPath.startsWith(".private/") && !objectPath.startsWith("/")) {
      pathsToTry.push(`.private/${objectPath}`);
    }
    
    // Strategy 4: Try without leading slash
    if (objectPath.startsWith("/")) {
      pathsToTry.push(objectPath.slice(1));
    }
    
    // Try each path until one works
    for (const storagePath of pathsToTry) {
      const result = await this.client.downloadAsBytes(storagePath);
      if (result.ok) {
        return { data: this.toBuffer(result.value), exists: true };
      }
    }
    
    // None of the paths worked
    throw new ObjectNotFoundError();
  }

  async deleteObject(storagePath: string): Promise<void> {
    const result = await this.client.delete(storagePath);
    if (!result.ok) {
      console.warn(`[ObjectStorage] Delete failed for ${storagePath}`);
    }
  }

  async objectExists(objectPath: string): Promise<boolean> {
    if (!objectPath.startsWith("/objects/")) {
      return false;
    }

    const parts = objectPath.slice(1).split("/");
    if (parts.length < 2) {
      return false;
    }

    const entityId = parts.slice(1).join("/");
    const storagePath = `.private/${entityId}`;
    
    const result = await this.client.exists(storagePath);
    return result.ok && result.value;
  }

  async listFiles(prefix?: string, limit = 1000): Promise<string[]> {
    try {
      const opts: any = { limit };
      if (prefix) opts.prefix = prefix;
      const result = await this.client.list(opts);
      if (!result.ok) return [];
      const files = (result as any).value || [];
      return files.map((f: any) => {
        const name = f.name || f;
        return name.replace(/^\.private\//, "");
      });
    } catch {
      return [];
    }
  }

  // Downloads an object to the response.
  async downloadObject(objectPath: string, res: Response) {
    try {
      const { data } = await this.getObject(objectPath);
      
      // Try to determine content type from the path
      let contentType = "application/octet-stream";
      if (objectPath.includes(".")) {
        const ext = objectPath.split(".").pop()?.toLowerCase();
        const mimeTypes: Record<string, string> = {
          jpg: "image/jpeg",
          jpeg: "image/jpeg",
          png: "image/png",
          gif: "image/gif",
          webp: "image/webp",
          mp4: "video/mp4",
          webm: "video/webm",
          mov: "video/quicktime",
        };
        if (ext && mimeTypes[ext]) {
          contentType = mimeTypes[ext];
        }
      }
      
      res.set({
        "Content-Type": contentType,
        "Content-Length": data.length,
        "Cache-Control": "private, max-age=3600",
      });
      
      res.send(data);
    } catch (error) {
      console.error("Error downloading file:", error);
      if (!res.headersSent) {
        if (error instanceof ObjectNotFoundError) {
          res.status(404).json({ error: "Object not found" });
        } else {
          res.status(500).json({ error: "Error downloading file" });
        }
      }
    }
  }

  normalizeObjectEntityPath(rawPath: string): string {
    // If it's already a normalized path, return it
    if (rawPath.startsWith("/objects/")) {
      return rawPath;
    }
    return rawPath;
  }

  // Sets the ACL policy for an object (stores metadata alongside the object)
  async trySetObjectEntityAclPolicy(
    rawPath: string,
    aclPolicy: ObjectAclPolicy
  ): Promise<string> {
    const normalizedPath = this.normalizeObjectEntityPath(rawPath);
    
    if (!normalizedPath.startsWith("/objects/")) {
      return normalizedPath;
    }

    // Store ACL as a separate metadata file
    const parts = normalizedPath.slice(1).split("/");
    const entityId = parts.slice(1).join("/");
    const aclPath = `.private/${entityId}.acl`;
    
    const aclData = JSON.stringify(aclPolicy);
    await this.client.uploadFromText(aclPath, aclData);
    
    return normalizedPath;
  }

  // Gets the ACL policy for an object
  async getObjectAclPolicy(objectPath: string): Promise<ObjectAclPolicy | null> {
    if (!objectPath.startsWith("/objects/")) {
      return null;
    }

    const parts = objectPath.slice(1).split("/");
    const entityId = parts.slice(1).join("/");
    const aclPath = `.private/${entityId}.acl`;
    
    const result = await this.client.downloadAsText(aclPath);
    
    if (!result.ok) {
      return null;
    }
    
    try {
      return JSON.parse(result.value) as ObjectAclPolicy;
    } catch {
      return null;
    }
  }

  async canAccessObjectEntity({
    userId,
    objectPath,
    requestedPermission,
  }: {
    userId?: string;
    objectPath: string;
    requestedPermission?: ObjectPermission;
  }): Promise<boolean> {
    const aclPolicy = await this.getObjectAclPolicy(objectPath);
    
    if (!aclPolicy) {
      return false;
    }
    
    if (aclPolicy.owner === userId) {
      return true;
    }
    
    if (aclPolicy.visibility === "public" && requestedPermission === ObjectPermission.READ) {
      return true;
    }
    
    return false;
  }

  async uploadFromLocalDir(
    localDir: string,
    storagePrefix: string = ".private/uploads",
    options?: { skipExisting?: boolean; fileFilter?: (name: string) => boolean }
  ): Promise<{ uploaded: number; skipped: number; errors: string[] }> {
    const skipExisting = options?.skipExisting ?? true;
    const fileFilter = options?.fileFilter ?? ((name: string) => /\.(jpg|jpeg|png|gif|webp|pdf|mp4|webm|mov)$/i.test(name));

    if (!fs.existsSync(localDir)) {
      throw new Error(`Directory not found: ${localDir}`);
    }

    const files = fs.readdirSync(localDir).filter(f => {
      const fullPath = path.join(localDir, f);
      return fs.statSync(fullPath).isFile() && fileFilter(f);
    });

    let uploaded = 0, skipped = 0;
    const errors: string[] = [];

    for (const fileName of files) {
      const storagePath = `${storagePrefix}/${fileName}`;
      try {
        if (skipExisting) {
          const existsResult = await this.client.exists(storagePath);
          if (existsResult.ok && existsResult.value) {
            skipped++;
            continue;
          }
        }

        const buffer = fs.readFileSync(path.join(localDir, fileName));
        const result = await this.client.uploadFromBytes(storagePath, buffer);
        if (result.ok) {
          uploaded++;
        } else {
          errors.push(`Upload failed: ${fileName}`);
        }
      } catch (err: any) {
        errors.push(`${fileName}: ${err.message}`);
      }
    }

    return { uploaded, skipped, errors };
  }

  async copyBetweenBuckets(
    sourceBucketId: string,
    sourcePrefix: string,
    destPrefix: string,
    options?: { skipExisting?: boolean }
  ): Promise<{ copied: number; skipped: number; missing: number; errors: string[] }> {
    const sourceClient = getStorageClient(sourceBucketId);
    const skipExisting = options?.skipExisting ?? true;

    let copied = 0, skipped = 0, missing = 0;
    const errors: string[] = [];

    const listResult = await sourceClient.list({ prefix: sourcePrefix });
    if (!listResult.ok) {
      throw new Error(`Cannot list source bucket: ${JSON.stringify(listResult)}`);
    }

    const files = (listResult as any).value || [];
    for (const file of files) {
      const fileName = file.name || file;
      const destPath = fileName.replace(sourcePrefix, destPrefix);

      try {
        if (skipExisting) {
          const existsResult = await this.client.exists(destPath);
          if (existsResult.ok && existsResult.value) {
            skipped++;
            continue;
          }
        }

        const downloadResult = await sourceClient.downloadAsBytes(fileName);
        if (!downloadResult.ok) {
          missing++;
          continue;
        }

        const data = this.toBuffer(downloadResult.value);
        const uploadResult = await this.client.uploadFromBytes(destPath, data);
        if (uploadResult.ok) {
          copied++;
        } else {
          errors.push(`Upload failed: ${destPath}`);
        }
      } catch (err: any) {
        errors.push(`${fileName}: ${err.message}`);
      }
    }

    return { copied, skipped, missing, errors };
  }
}

export { ObjectPermission } from "./objectAcl";
